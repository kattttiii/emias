﻿using emias.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace emias.View
{
    /// <summary>
    /// Логика взаимодействия для UserAuth.xaml
    /// </summary>
    public partial class UserAuth : Window
    {
        public UserAuth()
        {
            InitializeComponent();
            DataContext = new UserAuthVM();
        }
        private void CanExecute(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = true;
        private void Max(object sender, ExecutedRoutedEventArgs e)
        {
            SystemCommands.MaximizeWindow(this);
            if (WindowState == WindowState.Maximized) SystemCommands.RestoreWindow(this);
        }
        private void Hide(object sender, ExecutedRoutedEventArgs e) => SystemCommands.MinimizeWindow(this);
        private void Close(object sender, ExecutedRoutedEventArgs e) => SystemCommands.CloseWindow(this);
    }
}
