﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    internal class oms
    {
        public int OMS { get; set; }
        public string surname { get; set; }
        public string name { get; set; }
        public string patronymic { get; set; }
        public string birthday { get; set; }
        public string address { get; set; }
        public string livingaddress;
        public string phone;
        public string email;
        public string nickname;

        public oms(int oMS, string surname, string name, string patronymic, string birthday, string address, string livingaddress, string phone, string email, string nickname)
        {
            OMS = oMS;
            this.surname = surname;
            this.name = name;
            this.patronymic = patronymic;
            this.birthday = birthday;
            this.address = address;
            this.livingaddress = livingaddress;
            this.phone = phone;
            this.email = email;
            this.nickname = nickname;
        }
        public Dictionary<string, object> get_data() => new Dictionary<string, object>()
        {
            {"oms",OMS },
            {"surname",surname},
            {"name",name},
            {"patronymic",patronymic},
            {"birthday",birthday},
            {"address",address},
            {"livingaddress",livingaddress}

        };
        public string get_FIO() => name+" "+surname+" "+patronymic;
    }
}
