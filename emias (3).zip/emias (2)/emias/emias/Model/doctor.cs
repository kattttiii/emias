﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    class doctor
    {
        public int id;
        public string surname;
        public string name;
        public string patronymic;
        public int speciality_id;
        public string enterpassword;
        public string workaddress;

        public doctor(int id, string surname, string name, string patronymic, int speciality_id, string enterpassword, string workaddress)
        {
            this.id = id;
            this.surname = surname;
            this.name = name;
            this.patronymic = patronymic;
            this.speciality_id = speciality_id;
            this.enterpassword = enterpassword;
            this.workaddress = workaddress;
        }
    }
}
