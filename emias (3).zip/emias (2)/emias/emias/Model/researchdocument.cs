﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    class researchdocument
    {
        public int id;
        public int appointments_id;
        public string rtf;
        public byte[] attachment;

        public researchdocument(int id, int appointments_id, string rtf, byte[] attachment)
        {
            this.id = id;
            this.appointments_id = appointments_id;
            this.rtf = rtf;
            this.attachment = attachment;
        }
    }
}
