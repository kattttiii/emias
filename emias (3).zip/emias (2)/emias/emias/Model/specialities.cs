﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    class specialities
    {
        public int id;
        public string name;

        public specialities(int id, string name)
        {
            this.id = id;
            this.name = name;
        }
    }
}
