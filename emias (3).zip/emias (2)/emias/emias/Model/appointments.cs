﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    class appointments
    {
        public int id;
        public int oms_id;
        public int doctor_id;
        public string appointmentsdate;
        public string appointmentstime;
        public int status_id;

        public appointments(int id, int oms_id, int doctor_id, string appointmentsdate, string appointmentstime, int status_id)
        {
            this.id = id;
            this.oms_id = oms_id;
            this.doctor_id = doctor_id;
            this.appointmentsdate = appointmentsdate;
            this.appointmentstime = appointmentstime;
            this.status_id = status_id;
        }
    }
}
