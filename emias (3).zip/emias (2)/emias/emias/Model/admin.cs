﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    class admin
    {
        public int id;
        public string surname { get; set; }
        public string name { get; set; }
        public string patronymic { get; set; }
        public string enterpassword { get; set; }

        public admin(int id, string surname, string name, string patronymic, string enterpassword)
        {
            this.id = id;
            this.surname = surname;
            this.name = name;
            this.patronymic = patronymic;
            this.enterpassword = enterpassword;
        }
        public Dictionary<string, object> get_data() => new Dictionary<string, object>()
        {
            {"surname", surname},
            {"name", name},
            {"patronymic", patronymic},
            {"enterpassword", enterpassword}
        };
    }
}
