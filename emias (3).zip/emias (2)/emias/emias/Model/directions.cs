﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    class directions
    {
        public int id;
        public int speciality_id;
        public int oms_id;

        public directions(int id, int speciality_id, int oms_id)
        {
            this.id = id;
            this.speciality_id = speciality_id;
            this.oms_id = oms_id;
        }
    }
}
