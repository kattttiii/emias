﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.Model
{
    class analysdocument
    {
        public int id;
        public int appointments_id;
        public string rtf;

        public analysdocument(int id, int appointments_id, string rtf)
        {
            this.id = id;
            this.appointments_id = appointments_id;
            this.rtf = rtf;
        }
    }
}
