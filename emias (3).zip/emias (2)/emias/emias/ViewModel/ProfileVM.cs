﻿using emias.Model;
using emias.Properties;
using emias.View;
using emias.ViewModel.Helpers;
using Logics;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace emias.ViewModel
{
    internal class ProfileVM : BindingHelper
    {
        oms OMS;
        public oms oms
        {
            get => OMS; set
            {
                OMS = value;
                FIO = value.get_FIO();
                OnPropertyChanged();
            }
        }
        string fio;
        public string FIO
        {
            get => fio;
            set
            {
                fio = value;
                OnPropertyChanged();
            }
        }
        string theme = Settings.Default.theme == "dark" ? "Темная" : "Светлая";
        public BindableCommand Back { get; set; }
        public BindableCommand Copy { get; set; }
        public BindableCommand BackMain { get; set; }
        public string Theme
        {
            get => theme;
            set
            {
                theme = value;
                Settings.Default.theme = value == "Темная" ? "dark" : "light";
                Settings.Default.Save();
                Application.Current.Resources.MergedDictionaries.Clear();
                Application.Current.Resources.MergedDictionaries.Insert(0, new ResourceDictionary { Source = new Uri($"pack://application:,,,/Colors;component/{Settings.Default.theme}.xaml") });
                OnPropertyChanged();
            }
        }
        ObservableCollection<string> themes = new ObservableCollection<string>() { "Темная", "Светлая" };
        public ObservableCollection<string> Themes
        {
            get => themes;
            set
            {
                themes = value;
                OnPropertyChanged();
            }
        }
        public ProfileVM()
        {
            foreach (var a in API.Get<List<oms>>("oms")) if (a.OMS == Settings.Default.oms) oms = a;
            Back = new BindableCommand(_ => new UserAuth().Show());
            Copy = new BindableCommand(_ => copy());
            BackMain = new BindableCommand(_ => new MainUserWindow().Show());

        }
        void copy()
        {
            var data = new DataObject();
            data.SetData(DataFormats.UnicodeText,oms.livingaddress,true);
            var thread = new Thread(() => Clipboard.SetDataObject(data, true));
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();
            MessageBox.Show("Адрес прописки скопирован в буфер обмена", "Оповещение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
