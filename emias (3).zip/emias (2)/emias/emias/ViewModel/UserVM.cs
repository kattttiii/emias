﻿using emias.Model;
using emias.Properties;
using emias.View;
using emias.ViewModel.Helpers;
using Logics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace emias.ViewModel
{
    internal class UserVM : BindingHelper
    {
        string name;
        public string Name
        {
            get => name;
            set
            {
                name = value;
                OnPropertyChanged();
            }
        }
        public BindableCommand Profile { get; set; }
        public UserVM()
        {
            foreach (var a in API.Get<List<oms>>("oms")) if (a.OMS == Settings.Default.oms) Name = a.name;
            Profile = new BindableCommand(_ => new Profile().Show());
        }
    }
}
