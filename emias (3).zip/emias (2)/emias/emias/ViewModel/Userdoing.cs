﻿using emias.Model;
using emias.Properties;
using emias.ViewModel.Helpers;
using Logics;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace emias.ViewModel
{
    class Userdoing : BindingHelper
    {
        public BindableCommand Create { get; set; }
        public BindableCommand Delete { get; set; }
        oms patient;
        public oms Patient
        {
            get => patient;
            set
            {
                patient = value;
                OnPropertyChanged();
            }
        }
        ObservableCollection<oms> patients;
        public ObservableCollection<oms> Patients
        {
            get => patients;
            set
            {
                patients = value;
                OnPropertyChanged();
            }
        }
        ObservableCollection<string> roles;
        public ObservableCollection<string> Roles
        {
            get => roles;
            set
            {
                roles = value;
                OnPropertyChanged();
            }
        }
        string selected_role;
        public string Selected_role
        {
            get => selected_role;
            set
            {
                Settings.Default.check_role = value;
                selected_role = value;
                OnPropertyChanged();
            }
        }
        public Userdoing()
        {
            Roles = new ObservableCollection<string>() { "admin", "doctor", "user" };
            Create = new BindableCommand(_ => create());
            Delete = new BindableCommand(_ => delete());
            Patients = API.Get<ObservableCollection<oms>>("oms");
        }
        void create()
        {
            API.Put("oms", Patient.get_data());
            Patients = API.Get<ObservableCollection<oms>>("oms");
        }
        void delete()
        {
            API.delete("oms", "oms",Patient.OMS);
            Patients = API.Get<ObservableCollection<oms>>("oms");
        }
    }
}
