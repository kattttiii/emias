﻿using emias.Model;
using emias.Properties;
using emias.ViewModel.Helpers;
using Logics;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace emias.ViewModel
{
    internal class Admindoing : BindingHelper
    {
        public BindableCommand Create { get; set; }
        public BindableCommand Delete { get; set; }
        admin patient;
        public admin Patient
        {
            get => patient;
            set
            {
                patient = value;
                OnPropertyChanged();
            }
        }
        ObservableCollection<admin> patients;
        public ObservableCollection<admin> Patients
        {
            get => patients;
            set
            {
                patients = value;
                OnPropertyChanged();
            }
        }
        ObservableCollection<string> roles;
        public ObservableCollection<string> Roles
        {
            get => roles;
            set
            {
                roles = value;
                OnPropertyChanged();
            }
        }
        string selected_role;
        public string Selected_role
        {
            get => selected_role;
            set
            {
                Settings.Default.check_role = value;
                selected_role = value;
                OnPropertyChanged();
            }
        }
        public Admindoing()
        {
            Roles = new ObservableCollection<string>() { "admin", "doctor", "user" };
            Create = new BindableCommand(_ => create());
            Delete = new BindableCommand(_ => delete());
            Patients = API.Get<ObservableCollection<admin>>("admin");
        }
        void create()
        {
            API.Put("admin", Patient.get_data());
            Patients = API.Get<ObservableCollection<admin>>("admin");
        }
        void delete()
        {
            if (Settings.Default.numberWorker == Patient.id)
            {
                MessageBox.Show("Вы не можете удалить сами себя");
                return;
            }
            API.delete("oms", "oms", Patient.id);
            Patients = API.Get<ObservableCollection<admin>>("admin");
        }
    }
}
