﻿using emias.Model;
using emias.Properties;
using emias.View;
using emias.ViewModel.Helpers;
using Logics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace emias.ViewModel
{
    internal class UserAuthVM : BindingHelper
    {
        string polis;
        public string Polis
        {
            get => polis;
            set
            {
                polis = value;
                OnPropertyChanged();
            }
        }
        public BindableCommand Back { get; set; }
        public BindableCommand Auth { get; set; }
        public UserAuthVM()
        {
            Back = new BindableCommand(_ => new MainWindow().Show());
            Auth = new BindableCommand(_ => auth());
        }
        void auth()
        {
            bool auth = false;
            foreach (var a in API.Get<List<oms>>("oms")) if (polis == a.OMS.ToString()) { auth = true; Settings.Default.oms = a.OMS; }
            if (auth) new MainUserWindow().Show();
            else
            {
                MessageBox.Show("Полис введен неккоректно");
                new UserAuth().Show();
            }
        }
    }
}
