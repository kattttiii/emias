﻿using emias.Properties;
using emias.ViewModel.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace emias.ViewModel
{
    internal class Doctordoing : BindingHelper
    {
        ObservableCollection<string> roles;
        public ObservableCollection<string> Roles
        {
            get => roles;
            set
            {
                roles = value;
                OnPropertyChanged();
            }
        }
        string selected_role;
        public string Selected_role
        {
            get => selected_role;
            set
            {
                Settings.Default.check_role = value;
                selected_role = value;
                OnPropertyChanged();
            }
        }
        public Doctordoing()
        {
            Roles = new ObservableCollection<string>() { "admin", "doctor", "user" };
        }
    }
}
