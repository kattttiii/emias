﻿using Colors.Themes;
using emias.Properties;
using emias.View;
using emias.ViewModel.Helpers;
using Logics;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace emias.ViewModel
{
    class AdminVM : BindingHelper
    {
        public BindableCommand Back { get; set; }
        Page frame;
        public Page Frame
        {
            get => frame;
            set
            {
                frame = value;
                OnPropertyChanged();
            }
        }
        public AdminVM()
        {
            Frame = new CRUDUser();
            Back = new BindableCommand(_ => back());
            new Task(() =>
            {
                string role = Settings.Default.check_role;
                while (Settings.Default.check_role != "None")
                {
                    while (role == Settings.Default.check_role) { }
                    role = Settings.Default.check_role;
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        if (role == "user") Frame = new CRUDUser();
                        else if (role == "admin") Frame = new CRUDAdmin();
                        else if (role == "doctor") Frame = new CRUDDoctor();
                    });

                }
            }).Start();
        }
        void back() => new MainWindow().Show();
    }
}
