﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using emias.Model;
using emias.Properties;
using emias.View;
using emias.ViewModel.Helpers;
using Logics;

namespace emias.ViewModel
{
    internal class MainViewModel : BindingHelper
    {
        string numberWorker;
        public string NumberWorker
        {
            get => numberWorker;
            set
            {
                numberWorker = value;
                OnPropertyChanged();
            }
        }
        string password;
        public string Password
        {
            get => password;
            set
            {
                password = value;
                OnPropertyChanged();
            }
        }
        public BindableCommand AuthWorker { get; set; }
        public BindableCommand YaDolboyeb { get; set; }
        public BindableCommand Exit { get; set; }
        public MainViewModel()
        {
            if (Settings.Default.theme == "dark") Settings.Default.theme = "dark";
            else if (Settings.Default.theme != "light") Settings.Default.theme = "light";
            else Settings.Default.theme = "light";
            Settings.Default.Save();
            set_theme();
            AuthWorker = new BindableCommand(_ => authWorker());
            Exit = new BindableCommand(_ => Environment.Exit(0));
            YaDolboyeb = new BindableCommand(_ => new UserAuth().Show());

        }
        void set_theme()
        {
            Application.Current.Resources.MergedDictionaries.Clear();
            Application.Current.Resources.MergedDictionaries.Insert(0, new ResourceDictionary { Source = new Uri($"pack://application:,,,/Colors;component/{Settings.Default.theme}.xaml") });
        }

        void authWorker()
        {
            bool auth = false;
            string enter_role = "";
            foreach (var a in API.Get<List<admin>>("admin")) if (a.id.ToString() == numberWorker && a.enterpassword == password) { auth = true; enter_role = "admin"; Settings.Default.numberWorker = a.id; }
            foreach(var a in API.Get<List<doctor>>("doctor")) if (a.id.ToString() == numberWorker && a.enterpassword == password) { auth = true; enter_role = "doctor"; }
            if (auth && enter_role == "admin") new Admin().Show();
            else if (auth && enter_role == "doctor") new MainWindow().Show();
            else
            {
                MessageBox.Show("Неверные данные для входа");
                new MainWindow().Show();
            }
        }
    }
}
