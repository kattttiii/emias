﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Logics
{
    public class API
    {
        static string url = "http://127.0.0.1:5252/api";
        static HttpClient client = new HttpClient();
        public static T Get<T>(string table)
        {
            try
            {
                HttpResponseMessage message = client.GetAsync(url+"?table="+table).Result;
                return DeSerializer.deserilize<T>(message.Content.ReadAsStringAsync().Result);
            }
            catch { throw; }
        }
        public static bool Put(string table, Dictionary<string, object> kwargs)
        {
            try
            {
                kwargs.Add("table", table);
                string response = "?";
                foreach (var a in kwargs)
                {
                    if (a.Value != kwargs.Values.ToList()[kwargs.Values.ToList().Count - 1])
                        response += a.Key + "=" + a.Value + "&";
                    else response += a.Key + "=" + a.Value;

                }
                HttpResponseMessage message = client.PutAsync(url+response, new StringContent(DeSerializer.serilize(kwargs), Encoding.UTF8, "application/json")).Result;
                if (message.Content.ReadAsStringAsync().Result.ToString() != "") return true;
                else return false;
            }
            catch { throw; }
        }
        public static bool delete(string table,string arg,int id)
        {
            try
            {
                HttpResponseMessage message = client.DeleteAsync(url+"?table="+table+"&" + arg+"="+id).Result;
                if (message.Content.ReadAsStringAsync().Result == "ok") return true;
                else return false;
            }
            catch { throw; }
        }
    }
}
