﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logics
{
    public class DeSerializer
    {
        public static string serilize<T>(T obj) => JsonConvert.SerializeObject(obj);
        public static T deserilize<T>(string obj) => JsonConvert.DeserializeObject<T>(obj.Replace("None","''"));
    }
}
