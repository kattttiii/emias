from flask import Flask, jsonify, render_template, request
from bd import *
from threading import Thread


app = Flask(__name__)

bd = BD()

@app.route('/api', methods=['GET', 'POST', 'PUT', 'DELETE'])
def api():
    args = request.args
    table = args.get('table')
    id = args.get('id', default=0,type=int)
    newarg = ''
    if not id:
        id = args.get('oms')
        newarg = 'oms'
    if request.method == 'GET':
        return str(bd.selectBD(table)) if table else 'Не была указана таблица при указании запроса', 200
    elif request.method == 'POST':
        try:
            kwargs = dict(request.args)
            del kwargs['id']
            del kwargs['table']
            if id and kwargs and table:
                for i in kwargs:
                    bd.updateBD(table,i,bd.to_str(kwargs[i]) if not i.isdigit() else str(kwargs[i]),'id',str(id))
                return 'Изменение произошло успешно', 200
            elif not id: return 'Не указан id для изменения', 400
            elif not table: return 'Не указана таблица для изменения', 400
        except Exception as e:
            return f'Произошла ошибка:  {e}', 400
    elif request.method == 'PUT':
        try:
            kwargs = dict(request.args)
            del kwargs['table']
            if table:
                kwargs_ = dict()
                for i in kwargs:
                    if kwargs[i].isdigit():
                        kwargs_[i] = kwargs[i]
                    else: kwargs_[i] = bd.to_str(kwargs[i])
                bd.inputBD(table,newkwargs=kwargs_)
                return 'Добавление произошло успешно', 200
            elif not table: return 'Не указана таблица для добавления', 400
        except Exception as e:
            print(f'Произошла ошибка:  {e}')
            return f'Произошла ошибка:  {e}', 400
    elif request.method == 'DELETE':
        try:
            if table and id:
                if newarg:
                    bd.deleteBD(table,id,newarg)
                else:
                    bd.deleteBD(table,id)
                return 'Удаление произошло успешно', 200
            elif not id: return 'Не указан id для изменения', 400
            elif not table: return 'Не указана таблица для добавления', 400
        except Exception as e:
            return f'Произошла ошибка:  {e}', 400
        
if __name__ == "__main__":
    if not bd.selectBD("admin"):
        bd.inputBD('admin',surname=bd.to_str('admin'),name=bd.to_str('admin'),patronymic=bd.to_str('admin'),enterpassword=bd.to_str('1234'))
    if not bd.selectBD("oms"):
        bd.inputBD('oms',oms='5252',surname=bd.to_str('admin'),name=bd.to_str('admin'),patronymic=bd.to_str('admin'),birthday=bd.to_str('15.05.2020'),address=bd.to_str('Нахимовский проспект, 21'),livingaddress=bd.to_str('Нахимовский проспект, 21'))
    app.run(host='0.0.0.0', port=5252)
