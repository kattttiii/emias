import psycopg2, datetime, json, psycopg2.extras
class BD:
    connect = psycopg2.connect(
        host = "127.0.0.1",
        user = "postgres",
        password = "pogoda00",
        database = "emias"
        )
    # Вызывать функцию для корректной работы с бд, ведь запросы пишутся напрямую а не через функцию
    @classmethod
    def to_str(self, input):
        return "\'"+str(input)+"\'"

    # Шаблоны всех CRUD и выборка одной строки таблицы
    def inputBD(self, table, newkwargs=None,**kwargs):
        '''
        Шаблонная функция позволяющяя добавить в таблицу бд по названию, принимает в себя **kwargs, который является аргументом для функции ввода данных в таблицу\n
        Пример: \n
            bd = BD()\n
            bd.insertBD('test_table', title=bd.to_str('название'), description=bd.to_str('описание'), qwerty=bd.to_str('строка'))\n
        Вывод данных в запрос:\n
            insert into test_table(title, description, qwerty) values('название', 'описание','строка')\n
        Ошибки при неипользовании to_str():\n
            bd.insertBD('test_table', title='название', description=bd.to_str('описание'), qwerty=bd.to_str('строка'))\n
            insert into test_table(title, description, qwerty) values(название, 'описание','строка')
            \t\t\t\t\t\t\t\t\t\t\t^
        Ввод неккоректного типа данных для столбца
        '''
        if newkwargs:
            with self.connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                print(str(kwargs))
                cursor.execute(f"""
                insert into {table}({', '.join(list(newkwargs.keys()))}) values({', '.join([newkwargs[i] for i in newkwargs])});
                """)
                self.connect.commit()
        else:
            with self.connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
                print(str(kwargs))
                cursor.execute(f"""
                insert into {table}({', '.join(list(kwargs.keys()))}) values({', '.join([kwargs[i] for i in kwargs])});
                """)
                self.connect.commit()
            
    def selectBD(self, table):
        with self.connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            cursor.execute(f"""
            select * from {table};
            """)
            self.connect.commit()
            values = cursor.fetchall()
            return json.loads(json.dumps([dict(i) for i in values], ensure_ascii=False, default=str))
                

    def oneSelectBD(self, table, type,value):
        with self.connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            cursor.execute(f"""
            select * from {table} where {type} = {value};
            """)
            result = cursor.fetchone()
            self.connect.commit()
            return json.loads(json.dumps(dict(result), ensure_ascii=False, default=str))
        
    
    def updateBD(self, table, set_type, value_type, find_type,value_find):
        with self.connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            cursor.execute(f"""
            update {table} set {set_type} = {value_type} where {find_type} = {value_find};
            """)
            self.connect.commit()

    def deleteBD(self, table, id, newarg = ''):
        with self.connect.cursor(cursor_factory=psycopg2.extras.DictCursor) as cursor:
            if newarg:
                cursor.execute(f"""
                delete from {table} where {newarg} = {int(id)};
                """)
            else:
                cursor.execute(f"""
                delete from {table} where id = {int(id)};
                """)
        self.connect.commit()